// Fill these two values from: Supabase Dashboard -> Project Settings -> API
// (use the project URL and the "anon" / publishable key — NEVER the service_role key here)
window.OR_CONFIG = {
  url: 'https://YOUR-PROJECT.supabase.co',
  anonKey: 'YOUR-ANON-PUBLIC-KEY'
};
